<?php
class Start{
    public function __construct(){
		//开发版 不含框架下载链接
		echo '<style type="text/css">*{ padding: 0; margin: 0; } a{text-decoration: none;color: grey} h1{ font-size: 100px; font-weight: normal; margin-bottom: 12px; } p{ line-height: 1.6em; font-size: 42px }</style><div style="padding: 24px 48px;"><h1>EASYLT</h1><p><span style="font-size:28px">欢迎使用EASYLT v2.0&nbsp&nbsp一款MSVP多场景PHP框架</span></p><br /><span style="font-size:20px;"><a href="' .VIEW_PUBLIC.'/href/view_mysql_test">点击进入view视图mysql测试页面</a><br /><br /><a href="' .VIEW_PUBLIC.'/href/view_redis_test">点击进入view视图&nbspredis&nbsp测试页面</a><br /><br /><a href="' .VIEW_PUBLIC.'/href/websocket_test">点击进入websocket连接测试页面</a><br /><br /><a href="' .VIEW_PUBLIC.'/href/rpc_test">点击开始&nbsp&nbspRPC&nbsp&nbsp远程过程调用测试</a></span></div>';
    }
}






